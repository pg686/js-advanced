
import {render} from "./../node_modules/lit-html/lit-html.js";
import {allRows } from "./templates/tableTemplate.js"


let tbody = document.querySelector('.container tbody');
let response = await fetch('http://localhost:3030/jsonstore/advanced/table');
let dataObj = await  response.json();
let students = Object.values(dataObj).map(s => ({
 name: `${s.firstName} ${s.lastName}`,
 course: s.course,
 email: s.email
}))
render(allRows(students), tbody);

 

 function solve() {

 
   document.querySelector('#searchBtn').addEventListener('click', onClick);

   function onClick() {
      //   TODO:
      let searchField = document.querySelector('#searchField');
      let tbodyEl = document.querySelector('.container tbody');
let searchText = searchField.value.toLowerCase();
let tdAll = [...tbodyEl.querySelectorAll('td')];
let filtered = tdAll.filter(el => el.textContent.toLowerCase().includes(searchText));
console.log(filtered)
   }
}

